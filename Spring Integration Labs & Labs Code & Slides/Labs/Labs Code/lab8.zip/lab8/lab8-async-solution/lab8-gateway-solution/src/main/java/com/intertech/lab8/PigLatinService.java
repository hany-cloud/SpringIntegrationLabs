package com.intertech.lab8;

public interface PigLatinService {

	String translate(String english);

}
