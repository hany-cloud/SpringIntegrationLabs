package com.intertech.lab8;

public class PrintingSA {

	public void showResults(String translation) {
		System.out.println(translation);
	}

}
