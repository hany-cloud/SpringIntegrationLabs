package com.intertech.lab5;

public class ExampleServiceActivator {
	
	public void printShiporder(Object order){
		System.out.println(order);
	}

}
