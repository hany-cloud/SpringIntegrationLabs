package com.intertech.lab6;

public class ExampleServiceActivator {
	
	public void printShiporder(Object order){
		System.out.println(order);
	}

}
